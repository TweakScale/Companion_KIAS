# TweakScale Companion :: Kerbal Inventory System (KIS) :: Change Log

* 2020-0505: 0.0.1.1 Alpha (LisiasT) for KSP >= 1.2.2
	+ Added the DLLs, as TweakScale 2.5.0.11 (with the new methods) are on the wild.
* 2020-0503: 0.0.1.0 Alpha (LisiasT) for KSP >= 1.2.2
	+ Initial public version for testing 