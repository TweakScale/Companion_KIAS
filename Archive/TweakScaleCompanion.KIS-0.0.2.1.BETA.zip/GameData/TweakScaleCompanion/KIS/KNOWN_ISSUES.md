# TweakScale Companion :: Kerbal Inventory System (KIS) :: Known Issues

* This thing **is Alpha** and should be considered unfit for production
* It only works with TweakScale 2.5.0.11 (currently in Beta) or later.
* Changing the Scaling type for KIS Containers does not trigger the rescaling code - you need to rescale the part to something else and then scale back.
* The current cost scaling my be too harsh?
* There's no UI to scale the Basket Ball and the Book!