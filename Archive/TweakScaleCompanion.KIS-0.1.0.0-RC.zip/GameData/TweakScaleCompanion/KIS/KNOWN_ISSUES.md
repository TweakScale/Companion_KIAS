# TweakScale Companion :: Kerbal Inventory System (KIS) :: Known Issues

* This thing should not be used on Production without automated backups, as [S.A.V.E.](https://forum.kerbalspaceprogram.com/index.php?/topic/94997-*/)
* It only works with TweakScale 2.4.4.0 or later.
* The current scaling costs may be too harsh?
* There's no UI to scale the Basket Ball and the Book!